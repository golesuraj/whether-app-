const form = document.querySelector("form");
const cityInput = document.querySelector("input[name='city']");
const weatherDiv = document.querySelector(".weather-info");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const city = cityInput.value;
    if (!city) return;

    const response = await fetch("/", {
        method: "POST",
        body: new URLSearchParams({ city })
    });

    // reload the page to show updated info (Flask template handles it)
    window.location.reload();
});
