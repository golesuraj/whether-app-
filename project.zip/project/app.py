from flask import Flask, render_template, request
import requests

app = Flask(__name__)

API_KEY = "1d37b4419c95da7a726343662e8454e1"

@app.route("/", methods=["GET", "POST"])
def index():
    weather_data = None

    if request.method == "POST":
        city = request.form.get("city")

        if city:
            try:
                response = requests.get(
                    "https://api.openweathermap.org/data/2.5/weather",
                    params={
                        "q": city,
                        "appid": API_KEY,
                        "units": "metric"
                    },
                    timeout=20
                )

                data = response.json()
                print("API RESPONSE:", data)

                if response.status_code == 200:
                    weather_data = {
                        "city": data["name"],
                        "country": data["sys"]["country"],
                        "temp": data["main"]["temp"],
                        "description": data["weather"][0]["description"].title(),
                        "icon": data["weather"][0]["icon"]
                    }
                else:
                    weather_data = {"error": data.get("message", "City not found")}

            except requests.exceptions.Timeout:
                weather_data = {"error": "Request timed out. Try again."}
            except requests.exceptions.ConnectionError:
                weather_data = {"error": "Network connection problem."}
            except Exception as e:
                weather_data = {"error": str(e)}

    return render_template("index.html", weather=weather_data)

if __name__ == "__main__":
    app.run(debug=True)
